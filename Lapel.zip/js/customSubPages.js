

// wow js plugin 
 new WOW().init();